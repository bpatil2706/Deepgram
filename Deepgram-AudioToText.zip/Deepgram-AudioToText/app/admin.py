from django.contrib import admin

# Register your models here.
from .models import Audio_store

admin.site.register(Audio_store)

# Create your views here.
from django.views.generic import TemplateView
from django.shortcuts import render
from django.http import HttpResponse
from .forms import AudioForm
from django.core.files.storage import FileSystemStorage
from deepgram_app.settings import *
# deepgram sdk
from deepgram import Deepgram
import asyncio
import json
import io
from django.http import FileResponse
from reportlab.pdfgen import canvas
from docx import Document
from datetime import datetime

content = ""

def audio_upload(request):
    global content
    uploaded_file = {}
    if request.method == 'POST':
        form = AudioForm(request.POST, request.FILES or None)
        if form.is_valid():
            form.save()
            myfile = request.FILES['record']
            fs = FileSystemStorage()
            file = fs.save(myfile.name, myfile)
            uploaded_file['url'] = fs.url(file).replace(
                '%', '_').replace('20', '').replace(' ', '_')
            print(uploaded_file)
            asyncio.run(main(uploaded_file['url']))
            with open('./audio.json', 'r') as j:
                contents = json.loads(j.read())
                content = contents['results']['channels'][0]['alternatives'][0]['transcript']
        return render(request, 'audio.html', {
            'uploaded_file': uploaded_file, 'audio_contents': contents['results']['channels'][0]
            ['alternatives'][0]['transcript']})
    else:
        form = AudioForm()
    return render(request, 'home.html', {'form': form})


# DEEPGRAM_API_KEY = env('DEEPGRAM_API')
DEEPGRAM_API_KEY = "01ae205d7a775f620969fbb58087449cbadb1f29"
MIMETYPE = 'audio/mpeg'


async def main(PATH_TO_FILE):
    # init the Deepgram SDK
    deepgram = Deepgram(DEEPGRAM_API_KEY)
    # open audio file
    audio = open('.{}'.format(PATH_TO_FILE), 'rb')
    if MIMETYPE == 'audio/wav':
        source = {'buffer': audio, 'mimetype': MIMETYPE}
    else:
        source = {'buffer': audio, 'mimetype': MIMETYPE}
    response = await deepgram.transcription.prerecorded(source, {'punctuate': True})
    # save it to json
    audio_json = open('./audio.json', 'w')
    audio_json.write(json.dumps(response, indent=2))


def save_as_pdf(request):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer)
    p.drawString(100, 100, content)
    p.showPage()
    p.save()
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename='hello.pdf')

def save_as_doc(request):
    document = Document()
    document.add_paragraph(content)
    buffer = io.BytesIO()
    document.save(buffer)
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename='report.doc')
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from .views import audio_upload, save_as_pdf, save_as_doc
from django.contrib.staticfiles.storage import staticfiles_storage
from django.views.generic.base import RedirectView

urlpatterns = [
    path("", audio_upload, name="home"),
    path("pdf", save_as_pdf, name="pdf"),
    path("doc", save_as_doc, name="word"),
    path(
        "favicon.ico",
        RedirectView.as_view(url=staticfiles_storage.url("favicon.ico")),
    ),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
